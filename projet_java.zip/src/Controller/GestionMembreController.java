package Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import Model.gestion_membre.Membre;

public class GestionMembreController {

    @FXML
    private TableView<Membre> tableMembres;
    @FXML
    private TableColumn<Membre, String> colId;
    @FXML
    private TableColumn<Membre, String> colNom;
    @FXML
    private TableColumn<Membre, String> colPrenom;
    @FXML
    private TableColumn<Membre, String> colAbonnement;
    @FXML
    private TableColumn<Membre, String> colTelephone;

    @FXML
    private Button btnAjouter;
    @FXML
    private Button btnModifier;
    @FXML
    private Button btnSupprimer;
    @FXML
    private Button btnRechercher;

    @FXML
    private Button BackButton;

    private ObservableList<Membre> membresList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // Initialiser les colonnes de la table
        colId.setCellValueFactory(new PropertyValueFactory<>("id")); // Remplacer par votre champ ID
        colNom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        colPrenom.setCellValueFactory(new PropertyValueFactory<>("prenom"));
        colAbonnement.setCellValueFactory(new PropertyValueFactory<>("abonnement"));
        colTelephone.setCellValueFactory(new PropertyValueFactory<>("telephone"));

        // Charger les données initiales (exemple vide ici)
        tableMembres.setItems(membresList);
    }

    @FXML
    private void handleAjouter() {
        // Implémenter l'ajout d'un membre
        System.out.println("Ajouter un membre");
    }

    @FXML
    private void handleModifier() {
        // Implémenter la modification d'un membre
        System.out.println("Modifier un membre");
    }

    @FXML
    private void handleSupprimer() {
        // Implémenter la suppression d'un membre
        System.out.println("Supprimer un membre");
    }

    @FXML
    private void handleRechercher() {
        // Implémenter la recherche d'un membre
        System.out.println("Rechercher un membre");
    }

    @FXML
    private void BackAction() {
        // Gérer l'action pour revenir en arrière ou quitter
        System.out.println("Retour au menu principal");
    }
}
