/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.GestionPersonnel;

/**
 *
 * @author pc
 */
public class EntraineurPersonnel extends Entraineur {
    private String Specialite;
    private float TarifHoraire;
        
    // Constructeur par défaut
    public EntraineurPersonnel() {
        super(); // Appelle le constructeur de la classe parent (Entraineur)
        this.Specialite = "Non spécifiée"; // Valeur par défaut
        this.TarifHoraire = 0.0f; // Valeur par défaut
    }

    // Constructeur paramétré
    public EntraineurPersonnel(String nomPers, String prenomPers, String emailPers, int agePers, String numTelPers, 
                               String certifications, String specialite, float tarifHoraire) {
        super(nomPers, prenomPers, emailPers, agePers, numTelPers, certifications); // Appel du constructeur parent
        this.Specialite = specialite;
        this.TarifHoraire = tarifHoraire;
    }

    // Getter pour la spécialité
    public String getSpecialite() {
        return Specialite;
    }

    // Setter pour la spécialité
    public void setSpecialite(String specialite) {
        this.Specialite = specialite;
    }

    // Getter pour le tarif horaire
    public float getTarifHoraire() {
        return TarifHoraire;
    }

    // Setter pour le tarif horaire
    public void setTarifHoraire(float tarifHoraire) {
        this.TarifHoraire = tarifHoraire;
    }

    // Méthode pour créer un plan personnalisé pour un client (simplifié ici)
    public void creerPlanPersonnalise(String objectif, int dureeEnHeures) {
        System.out.println("Création d'un plan personnalisé :");
        System.out.println("Objectif : " + objectif);
        System.out.println("Durée estimée : " + dureeEnHeures + " heures");
        System.out.println("Spécialité de l'entraîneur : " + this.Specialite);
        System.out.println("Tarif horaire : " + this.TarifHoraire + "€");
        // Ajoutez ici la logique de création d'un plan personnalisé en fonction des informations du client
    }

    // Méthode pour vérifier si l'entraîneur est certifié pour un type de spécialité
    public boolean estCertifiePour(String specialite) {
        if (this.Specialite.equalsIgnoreCase(specialite)) {
            System.out.println("L'entraîneur est certifié pour : " + specialite);
            return true;
        } else {
            System.out.println("L'entraîneur n'est pas certifié pour : " + specialite);
            return false;
        }
    }

    // Méthode pour afficher le profil de l'entraîneur personnel (inclut la spécialité et le tarif horaire)
    @Override
    public void afficherProfil() {
        super.afficherProfil(); // Appel du profil de la classe parente (Entraineur)
        System.out.println("Spécialité : " + Specialite);
        System.out.println("Tarif horaire : " + TarifHoraire + "€");
        System.out.println("================================");
    }
}
