/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.GestionPersonnel;

/**
 *
 * @author pc
 */
public class Entraineur extends Personne {
    private String certifications; 
            
     public Entraineur() {
        super();
        this.certifications = "Aucune";
    }

    // Constructeur paramétré
    public Entraineur(String nomPers, String prenomPers, String emailPers, int agePers, String numTelPers, String certifications) {
        super(nomPers, prenomPers, emailPers, agePers, numTelPers);
        this.certifications = certifications;
    }

    // Getter pour les certifications
    public String getCertifications() {
        return certifications;
    }

    // Setter pour les certifications
    public void setCertifications(String certifications) {
        this.certifications = certifications;
    }

    // Méthode pour vérifier la présence
    public boolean estPresent() {
        // Logique basique pour indiquer la présence (peut être personnalisée)
        System.out.println(NomPers + " est présent.");
        return true;
    }

    // Méthode pour afficher le profil de l'entraîneur (inclut les certifications)
    @Override
    public void afficherProfil() {
        super.afficherProfil(); // Appelle la méthode de la classe parent
        System.out.println("Certifications: " + certifications);
        System.out.println("================================");
    }

    // Méthode pour modifier les certifications
    public void modifierCertifications(String nouvelleCertification) {
        this.certifications = nouvelleCertification;
        System.out.println("Certifications mises à jour avec succès !");
    }
}
