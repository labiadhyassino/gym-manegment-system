package Model.gestion_membre;

/**
 * Classe finale représentant un casier.
 * Cette classe ne peut pas être héritée.
 */
public final class Casier { // Ajout du mot-clé final
  
    private final int idCasier;
    private int idMembre;
    private final int num; 
    private boolean occupation;
    private int codeAcces; 

    public Casier(int id, int idMembre, int num, boolean occupation, int codeAcces) {
        this.idCasier = id; 
        this.idMembre = idMembre; 
        this.num = num; 
        this.occupation = occupation; 
        this.codeAcces = codeAcces;
    }
    
    public boolean reserverCasier(int idMembre, int codeAcces) {
        if (!occupation) {
            this.idMembre = idMembre;
            this.occupation = true;
            return true;
        }
        return false;
    }

    public void libererCasier() {
        this.idMembre = 0;
        this.occupation = false;
    }

    public boolean estOccupe() {
        return occupation;
    }
}
