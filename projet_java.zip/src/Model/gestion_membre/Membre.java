package Model.gestion_membre;

import java.util.List;

public class Membre {
    private String nom;
    private List<DateAbonnement> abonnements;

    // Constructeur
    public Membre(String nom) {
        this.nom = nom;
    }

    // Getter et Setter
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public List<DateAbonnement> getAbonnements() {
        return abonnements;
    }

    public void setAbonnements(List<DateAbonnement> abonnements) {
        this.abonnements = abonnements;
    }

    // Méthode pour ajouter un abonnement
    public void ajouterAbonnement(DateAbonnement dateAbonnement) {
        this.abonnements.add(dateAbonnement);
    }
}
