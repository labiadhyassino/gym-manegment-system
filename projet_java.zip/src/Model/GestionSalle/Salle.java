/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.GestionSalle;
 
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author pc
 */
public class Salle {
    private String NomS;
    private String TypeActivite;
     
    private List<Materiel> materiel; // Liste du matériel disponible dans la salle
    
    // Constructeur par défaut
    public Salle() {
        this.materiel = new ArrayList<>();
    }

    // Constructeur paramétré pour initialiser la salle avec un nom et un type d'activité
    public Salle(String nomS, String typeActivite) {
        this.NomS = nomS;
        this.TypeActivite = typeActivite;
        this.materiel = new ArrayList<>();
    }
    
    // Getter et Setter pour les attributs de la salle
    public String getNomS() {
        return NomS;
    }

    public void setNomS(String nomS) {
        this.NomS = nomS;
    }

    public String getTypeActivite() {
        return TypeActivite;
    }

    public void setTypeActivite(String typeActivite) {
        this.TypeActivite = typeActivite;
    }

    public List<Materiel> getMateriel() {
        return materiel;
    }

    // Méthode pour ajouter du matériel à la salle
    public void ajouterMateriel(Materiel m) {
        materiel.add(m);
        System.out.println("Matériel ajouté à la salle : " + NomS);
    }

    // Méthode pour afficher le matériel dans la salle
    public void afficherMateriel() {
        System.out.println("Matériel dans la salle " + NomS + ":");
        for (Materiel m : materiel) {
            m.afficherMateriel();
        }
    }

    // Méthode pour afficher les détails de la salle
    public void afficherDetails() {
        System.out.println("Nom de la salle: " + NomS);
        System.out.println("Type d'activité: " + TypeActivite);
        afficherMateriel();
    }
}
